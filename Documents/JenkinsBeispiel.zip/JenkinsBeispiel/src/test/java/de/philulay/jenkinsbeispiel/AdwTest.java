/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.philulay.jenkinsbeispiel;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 *
 * @author Philipp
 */
public class AdwTest extends TestCase {
    
    public void testAd(){
        assertTrue(true);
    }
}
